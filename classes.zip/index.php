
<!DOCTYPE html>
<html>
<head>
	<title>Li - Fix</title>
	<!-- <meta http-equiv="refresh" content="0; URL=./complainer/index.php"/> -->
	<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
</head>
<body>
<?php echo "wtf";
	include_once './models/Database.php';
	$d = new models\Database();
	echo $d;
	echo "ha ha";
?>
</body>
</html>
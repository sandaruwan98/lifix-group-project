# group-project
## repair status
#### completed -> c
#### avilable -> a
#### assigned -> x
#### suggested -> s
#### emergency repair -> e



## repair return/used flag
####  used -> 0
####  returned -> 1


## Item request status
#### completed -> c
#### open -> o
#### denied -> d

## Stock Addition status
#### completed -> 1
#### not completed -> 0


## When Revoking access, 
#### access revoked -> 1
#### access not revoked -> 0  (when creating a new account, this set as default value)

## user occuFlag,
#### divisional secretaty ->1
#### Clerk ->2
#### Storekeeper ->3
#### Technician ->4



## user statusFlag,
#### reset ->0
#### in operation->1
#### suspended ->2



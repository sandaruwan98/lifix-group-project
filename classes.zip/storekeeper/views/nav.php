
<nav class="sidebar">
        <!-- <h2 class="link-text">MENU</h2> -->
        <ul>
            <li class="nav-logo"><span class="nav-link"><i class="fas fa-lightbulb"></i><span class="link-text"
                        style="margin-left: 5px;">Li-Fix</span> </span>
            </li>
            <!-- <li class="nav-item"><a class="nav-link" href="./index.php"><i class="fas fa-home"></i><span
                        class="link-text">Home</span> </a></li> -->
			<li class="nav-item"><a class="nav-link" href="./index.php"><i class='far fa-list-alt'></i><span
                        class="link-text"> Request Items</span></a></li>	
            <li class="nav-item"><a class="nav-link" href="./requestHistory.php"><i class="fas fa-history"></i><span
                            class="link-text">Item Request History</span></a></li>	
            <li class="nav-item"><a class="nav-link" href="./inventory.php"><i class='far fa-file-alt'></i><span
                class="link-text">Inventory Details</span></a></li>
            <li class="nav-item"><a class="nav-link" href="./returnitem.php"><i class="fas fa-file-invoice"></i><span
                class="link-text">Return Item</span></a></li>  	
            <li class="nav-item"><a class="nav-link" href="./../login/Logout.php"><i class="fas fa-sign-out-alt"></i><span class="link-text">LogOut</span></a></li>

        </ul>

    </nav>

    <script src="../js/slider.js"></script>
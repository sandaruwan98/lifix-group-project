
<h2 class="title-r">Item Requst 1</h2>
<h4 class="title-date">Date : 2020/11/17</h2>


<form method="POST" style="padding: 10px;" action="">
    <table class="content-table" >
        <thead>
            <tr>
                <th>ITEM NAME</th>
                <th>QUANTITY</th>

            </tr>
        </thead>
        <tbody>
            <tr>
                <td>LED BULB</td>
                <td>80</td>

            </tr>
            <tr>
                <td>LED BULB</td>
                <td>80</td>

            </tr>
            <tr>
                <td>SUNBOXES</td>
                <td>20</td>

            </tr>
            <tr>
                <td>WIRES</td>
                <td>50m</td>

            </tr>
            <tr>
                <td>FUSE</td>
                <td>20</td>

            </tr>
            <tr>
                <td>BULB</td>
                <td>80</td>

            </tr>
            <tr>
                <td>BULB</td>
                <td>80</td>

            </tr>
            <tr>
                <td>BULB</td>
                <td>80</td>

            </tr>
            <tr>
                <td>BULB</td>
                <td>80</td>

            </tr>

        </tbody>


    </table>




</form>

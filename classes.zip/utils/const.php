<?php

define ('DSFL',1);
define ('CleckFL',2);
define ('StorekeeperFL',3);
define ('TechnicianFL',4);


define ('USED_ITEM',0);
define ('RETURN_ITEM',1);

?>

<nav class="sidebar">
    <!-- <h2 class="link-text">MENU</h2> -->
    <ul>
        <li class="nav-logo"><span class="nav-link" href="#"><i class="fas fa-lightbulb"></i><span class="link-text" style="margin-left: 5px;">LiFix</span> </span>
        </li>
        <!-- <li class="nav-item"><a class="nav-link" href="./index.php"><i class="fas fa-home"></i><span class="link-text">Home</span> </a></li> -->
        <li class="nav-item"><a class="nav-link" href="./index.php"><i class="fas fa-columns"></i><span class="link-text">DailyRepairs</span> </a></li>
        <li class="nav-item"><a class="nav-link" href="./repairHistory.php"><i class="fas fa-history"></i><span class="link-text">RepairHistory</span></a></li>
        <li class="nav-item"><a class="nav-link" href="./purchase.php"><i class="fas fa-file-invoice"></i><span class="link-text">Purchases</span></a></li>
        <li class="nav-item"><a class="nav-link" href="./newlamp.php"><i class="fas fa-plus-square"></i><span class="link-text">LampPost</span></a></li>
        <li class="nav-item"><a class="nav-link" href="#"><i class="fas fa-cog"></i><span class="link-text">Settings</span></a></li>
        <li class="nav-item"><a class="nav-link" href="./../login/Logout.php"><i class="fas fa-sign-out-alt"></i><span class="link-text">LogOut</span></a></li>

    </ul>

</nav>

<script src="../js/slider.js"></script>